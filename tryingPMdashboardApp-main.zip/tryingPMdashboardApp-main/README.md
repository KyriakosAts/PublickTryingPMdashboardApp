# 🧨 Project Planner: The Passive-Aggressive Edition™

Welcome to the tool I built so I can eventually stop doing my actual job.

Yes, it plans projects.  
Yes, it tracks tasks.  
No, it doesn’t fix your broken deadlines or fill the existential void.

> “Finally, a tool that lets me automate the chaos I pretend to control.” – Burnt-out PM, probably

---

## 💼 Why This Exists

Because I got tired of:

- Updating the same Excel sheet 4 times a day
- Chasing down developers who “forgot” their estimates
- Sitting through meetings that could’ve been an email written by this app

So I made this.  
One day, it’ll replace me.  
Today, it just mocks me gently from the browser.

---

## 🧪 Tech Stack

| Tool          | Why it's here                                         |
|---------------|-------------------------------------------------------|
| React         | Because therapy is expensive                         |
| Vite          | Because waiting for builds is against my religion    |
| Tailwind CSS  | Utility-first, like my job description                |
| JavaScript    | Just like this project: loosely typed and unstable   |

---

## 🚀 How to Run It (So I Don't Have To)

```bash
git clone https://github.com/your-company/i-hate-my-job-planner.git
cd i-hate-my-job-planner
npm install
npm run dev

Then open http://localhost:5173
Where you'll be greeted by a UI that says:
“You did this to yourself.”
```

📦 What It Does (Instead of Me)
Tracks phases, tasks, and fake progress

Assigns blame, I mean, effort

Calculates costs while your soul depreciates

Provides the illusion of control with pretty colors

Helps me forget I work in tech

😵 Known Issues
Developers refuse to timebox anything

QA refuses to test anything

PMs refuse to understand anything

And yet, deadlines exist

🤖 Coming Soon
Auto-generate sprint retrospectives full of vague compliments

Mood-based UI themes (e.g. “Deadline Panic” mode)

One-button feature: Resign gracefully

📌 License
MIT. Use it, abuse it, automate your job with it.
Just don’t tell my manager I built it during a sprint retro.

Built with rage, coffee, and the faint hope that AI will take over soon.
