import React, { useState, useEffect } from 'react';
import Icon from './components/Icon';
import CostView from './components/CostView';
import GanttChart from './components/GanttChart';
import ResourceView from './components/ResourceView';
import TaskAssignmentEditor from './components/TaskAssignmentEditor';
import { formatDate, getDaysBetween, addDays } from './utils/dateUtils';
import projectData from './data/lastOfMe.json';
import { getPhaseColor } from './utils/colorUtils';
import { autoCalculateTaskDates } from './utils/dateCalculations';

const App = () => {
    const [darkMode, setDarkMode] = useState(false);
    const [activeView, setActiveView] = useState('planning');
    const [selectedProjects, setSelectedProjects] = useState([]);
    const [currentDateTime, setCurrentDateTime] = useState(new Date());
    
    // Load projects from JSON data and add missing status field
    const [projects, setProjects] = useState(() => {
        return projectData.projects.map(project => ({
            ...project,
            phases: project.phases.map(phase => ({
                ...phase,
                color: phase.color || getPhaseColor(phaseIndex), // Use existing color or generate new one
                tasks: phase.tasks.map(task => ({
                    ...task,
                    status: task.status || 'pending' // Add default status if missing
                }))
            }))
        }));
    });
    
    // Load teams from JSON data and add teamName property to members
    const [teams, setTeams] = useState(() => {
        return projectData.teams.map(team => ({
            ...team,
            members: team.members.map(member => ({
                ...member,
                teamName: team.name
            }))
        }));
    });
    
    useEffect(() => {
        if (projects.length > 0) {
            setSelectedProjects([projects[0].id]);
        }
    }, [projects]);
    
    useEffect(() => {
        if (darkMode) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }, [darkMode]);
    
    // Update current date/time every second
    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentDateTime(new Date());
        }, 1000);
        
        return () => clearInterval(timer);
    }, []);
    
    const findTeamMember = (memberId) => {
        console.log('findTeamMember called with:', memberId);
        console.log('Available teams:', teams.map(t => ({ name: t.name, memberCount: t.members.length })));
        
        for (const team of teams) {
            const member = team.members.find(m => m.id === memberId);
            if (member) {
                const foundMember = {
                    ...member,
                    teamName: team.name
                };
                console.log('Found member:', foundMember);
                return foundMember;
            }
        }
        console.warn('Team member not found:', memberId);
        console.log('All available members:', teams.flatMap(team => 
            team.members.map(member => ({ id: member.id, name: member.name, team: team.name }))
        ));
        return null;
    };
    
    const updateTask = (projectId, phaseId, taskId, updates) => {
        console.log('updateTask called:', { projectId, phaseId, taskId, updates });
        
        setProjects(projects.map(project => 
            project.id === projectId 
                ? {
                    ...project,
                    phases: project.phases.map(phase =>
                        phase.id === phaseId
                            ? {
                                ...phase,
                                tasks: phase.tasks.map(task =>
                                    task.id === taskId ? { 
                                        ...task, 
                                        ...updates 
                                    } : task
                                )
                            }
                            : phase
                    )
                }
                : project
        ));
        
        console.log('Task updated. New projects state will be set.');
    };
    
    const moveTask = (projectId, phaseId, taskId, direction) => {
        setProjects(projects.map(project => 
            project.id === projectId 
                ? {
                    ...project,
                    phases: project.phases.map(phase =>
                        phase.id === phaseId
                            ? {
                                ...phase,
                                tasks: (() => {
                                    const tasks = [...phase.tasks];
                                    const taskIndex = tasks.findIndex(t => t.id === taskId);
                                    if (taskIndex === -1) return tasks;
                                    
                                    const newIndex = direction === 'up' ? taskIndex - 1 : taskIndex + 1;
                                    if (newIndex < 0 || newIndex >= tasks.length) return tasks;
                                    
                                    [tasks[taskIndex], tasks[newIndex]] = [tasks[newIndex], tasks[taskIndex]];
                                    return tasks;
                                })()
                            }
                            : phase
                    )
                }
                : project
        ));
    };
    
    const calculatePhaseCost = (phase) => {
        return phase.tasks.reduce((sum, task) => {
            return sum + (task.assignments || []).reduce((taskSum, assignment) => {
                const member = findTeamMember(assignment.teamMemberId);
                return taskSum + (member ? assignment.days * member.rate : 0);
            }, 0);
        }, 0);
    };
    
    const calculateProjectTotals = (project) => {
        const cost = project.phases.reduce((sum, phase) => sum + calculatePhaseCost(phase), 0);
        const totalDays = project.phases.reduce((sum, phase) => 
            sum + phase.tasks.reduce((phaseSum, task) => 
                phaseSum + getDaysBetween(task.startDate, task.endDate), 0), 0);
        return { cost, totalDays };
    };
    
    const calculateResourceAllocation = () => {
        const byTeam = {};
        const byMember = {};
        
        teams.forEach(team => {
            byTeam[team.name] = { total: 0, tasks: [] };
            team.members.forEach(member => {
                byMember[member.id] = { total: 0, tasks: [] };
            });
        });
        
        projects.forEach(project => {
            project.phases.forEach(phase => {
                phase.tasks.forEach(task => {
                    (task.assignments || []).forEach(assignment => {
                        const member = findTeamMember(assignment.teamMemberId);
                        if (member) {
                            const teamName = member.teamName;
                            byTeam[teamName].total += assignment.days;
                            byTeam[teamName].tasks.push(task.name);
                            byMember[member.id].total += assignment.days;
                            byMember[member.id].tasks.push(task.name);
                        }
                    });
                });
            });
        });
        
        return { byTeam, byMember };
    };
    
    const checkForDelays = (task) => {
        const today = new Date();
        const endDate = new Date(task.endDate);
        const startDate = new Date(task.startDate);
        
        if (task.status === 'completed') {
            return { isDelayed: false, message: '' };
        }
        
        if (task.status === 'in-progress' && endDate < today) {
            const daysOverdue = getDaysBetween(task.endDate, today.toISOString().split('T')[0]);
            return { 
                isDelayed: true, 
                message: `Task is ${daysOverdue} days overdue` 
            };
        }
        
        if (task.status === 'pending' && startDate < today) {
            const daysLate = getDaysBetween(task.startDate, today.toISOString().split('T')[0]);
            return { 
                isDelayed: true, 
                message: `Task should have started ${daysLate} days ago` 
            };
        }
        
        return { isDelayed: false, message: '' };
    };
    
    const addProject = () => {
        const newProject = {
            id: `proj${Date.now()}`,
            name: 'New Project',
            phases: [{
                id: `phase${Date.now()}`,
                name: 'Phase 1',
                color: '#6366f1',
                tasks: []
            }]
        };
        setProjects([newProject, ...projects]); // Add to the beginning
    };
    
    const moveProject = (projectId, direction) => {
        const projectIndex = projects.findIndex(p => p.id === projectId);
        if (projectIndex === -1) return;
        
        const newIndex = direction === 'up' ? projectIndex - 1 : projectIndex + 1;
        if (newIndex < 0 || newIndex >= projects.length) return;
        
        const newProjects = [...projects];
        [newProjects[projectIndex], newProjects[newIndex]] = [newProjects[newIndex], newProjects[projectIndex]];
        setProjects(newProjects);
    };
    
    const addPhase = (projectId) => {
        const project = projects.find(p => p.id === projectId);
        const phaseIndex = project ? project.phases.length : 0;
        
        const newPhase = {
            id: `phase${Date.now()}`,
            name: 'New Phase',
            color: getPhaseColor(phaseIndex),
            tasks: []
        };
        setProjects(projects.map(p => 
            p.id === projectId 
                ? { ...p, phases: [...p.phases, newPhase] }
                : p
        ));
    };
    
    const addTask = (projectId, phaseId) => {
        const newTask = {
            id: `task${Date.now()}`,
            name: 'New Task',
            startDate: new Date().toISOString().split('T')[0],
            endDate: addDays(new Date().toISOString().split('T')[0], 7),
            status: 'pending',
            effort: { frontend: 1, backend: 1, design: 1 },
            assignments: [],
            dependencies: [],
            parallelizable: 0.8
        };
        
        setProjects(projects.map(project => 
            project.id === projectId 
                ? {
                    ...project,
                    phases: project.phases.map(phase =>
                        phase.id === phaseId
                            ? { ...phase, tasks: [...phase.tasks, newTask] }
                            : phase
                    )
                }
                : project
        ));
    };
    
    const deleteTask = (projectId, phaseId, taskId) => {
        setProjects(projects.map(project => 
            project.id === projectId 
                ? {
                    ...project,
                    phases: project.phases.map(phase =>
                        phase.id === phaseId
                            ? { ...phase, tasks: phase.tasks.filter(t => t.id !== taskId) }
                            : phase
                    )
                }
                : project
        ));
    };
    
    const deletePhase = (projectId, phaseId) => {
        setProjects(projects.map(project => 
            project.id === projectId 
                ? {
                    ...project,
                    phases: project.phases.filter(p => p.id !== phaseId)
                }
                : project
        ));
    };
    
    const deleteProject = (projectId) => {
        setProjects(projects.filter(p => p.id !== projectId));
        // Remove from selected projects if it was selected
        setSelectedProjects(selectedProjects.filter(id => id !== projectId));
    };
    
    const autoCalculatePhaseDates = (projectId, phaseId) => {
        setProjects(projects.map(project => 
            project.id === projectId 
                ? {
                    ...project,
                    phases: project.phases.map(phase =>
                        phase.id === phaseId
                            ? {
                                ...phase,
                                tasks: autoCalculateTaskDates(phase.tasks, phase.startDate)
                            }
                            : phase
                    )
                }
                : project
        ));
    };
    
    return (
        <div className={`min-h-screen transition-colors duration-200 ${darkMode ? 'dark bg-slate-900' : 'bg-gray-50'}`}>
            <div className="container mx-auto px-4 py-6">
                <header className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                            Ultimate Project Planning Tool
                        </h1>
                        <p className="text-gray-600 dark:text-gray-400 mt-1">
                            Because spreadsheets are for quitters
                        </p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                            {currentDateTime.toLocaleDateString('en-US', { 
                                weekday: 'short', 
                                year: 'numeric', 
                                month: 'short', 
                                day: 'numeric' 
                            })} {currentDateTime.toLocaleTimeString('en-US', { 
                                hour: '2-digit', 
                                minute: '2-digit',
                                second: '2-digit'
                            })}
                        </div>
                        
                        <button
                            onClick={() => setDarkMode(!darkMode)}
                            className="p-2 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                        >
                            <Icon name={darkMode ? 'sun' : 'moon'} className="w-5 h-5 text-gray-700 dark:text-gray-300" />
                        </button>
                        
                        <nav className="flex bg-gray-200 dark:bg-gray-700 rounded-lg p-1">
                            {[
                                { id: 'planning', label: 'Planning', icon: 'folder' },
                                { id: 'gantt', label: 'Gantt', icon: 'chart' },
                                { id: 'costs', label: 'Costs', icon: 'dollar' },
                                { id: 'resources', label: 'Resources', icon: 'users' }
                            ].map(view => (
                                <button
                                    key={view.id}
                                    onClick={() => setActiveView(view.id)}
                                    className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                                        activeView === view.id
                                            ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                                            : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                                    }`}
                                >
                                    <Icon name={view.icon} className="w-4 h-4" />
                                    {view.label}
                                </button>
                            ))}
                        </nav>
                    </div>
                </header>
                
                <main>
                    {activeView === 'planning' && (
                        <div className="space-y-6">
                            <div className="flex items-center justify-between">
                                <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">Project Planning</h2>
                                <button
                                    onClick={addProject}
                                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                                >
                                    <Icon name="plus" className="w-4 h-4" />
                                    Add Project
                                </button>
                            </div>
                            
                            {projects.map(project => (
                                <div key={project.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-lg p-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center gap-3 flex-1">
                                            <div className="flex flex-col gap-1">
                                                <button
                                                    onClick={() => moveProject(project.id, 'up')}
                                                    disabled={projects.findIndex(p => p.id === project.id) === 0}
                                                    className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed"
                                                    title="Move project up"
                                                >
                                                    <Icon name="chevronUp" className="w-4 h-4" />
                                                </button>
                                                <button
                                                    onClick={() => moveProject(project.id, 'down')}
                                                    disabled={projects.findIndex(p => p.id === project.id) === projects.length - 1}
                                                    className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed"
                                                    title="Move project down"
                                                >
                                                    <Icon name="chevronDown" className="w-4 h-4" />
                                                </button>
                                            </div>
                                            
                                            <input
                                                type="text"
                                                value={project.name}
                                                onChange={(e) => setProjects(projects.map(p => 
                                                    p.id === project.id ? { ...p, name: e.target.value } : p
                                                ))}
                                                className="text-xl font-semibold bg-transparent border-none outline-none text-gray-800 dark:text-gray-200 focus:bg-gray-50 dark:focus:bg-gray-700 px-2 py-1 rounded flex-1"
                                            />
                                        </div>
                                        
                                        <div className="flex items-center gap-2">
                                            <span className="text-sm text-gray-500 dark:text-gray-400">
                                                #{projects.findIndex(p => p.id === project.id) + 1}
                                            </span>
                                            <button
                                                onClick={() => deleteProject(project.id)}
                                                className="text-red-500 hover:text-red-700 p-1"
                                                title="Delete project"
                                            >
                                                <Icon name="trash" className="w-4 h-4" />
                                            </button>
                                            <button
                                                onClick={() => addPhase(project.id)}
                                                className="flex items-center gap-2 text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                                            >
                                                <Icon name="plus" className="w-4 h-4" />
                                                Add Phase
                                            </button>
                                        </div>
                                    </div>
                                    
                                    {project.phases.map(phase => (
                                        <div key={phase.id} className="mb-6 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                                            <div className="flex items-center justify-between mb-3">
                                                <div className="flex items-center gap-3">
                                                    <div 
                                                        className="w-4 h-4 rounded"
                                                        style={{ backgroundColor: phase.color }}
                                                    />
                                                    <input
                                                        type="text"
                                                        value={phase.name}
                                                        onChange={(e) => setProjects(projects.map(p => 
                                                            p.id === project.id 
                                                                ? {
                                                                    ...p,
                                                                    phases: p.phases.map(ph => 
                                                                        ph.id === phase.id ? { ...ph, name: e.target.value } : ph
                                                                    )
                                                                }
                                                                : p
                                                        ))}
                                                        className="font-medium bg-transparent border-none outline-none text-gray-700 dark:text-gray-300 focus:bg-gray-50 dark:focus:bg-gray-700 px-2 py-1 rounded"
                                                    />
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <button
                                                        onClick={() => autoCalculatePhaseDates(project.id, phase.id)}
                                                        className="flex items-center gap-1 text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 text-xs"
                                                        title="Auto-calculate all task dates in this phase"
                                                    >
                                                        <Icon name="calendar" className="w-3 h-3" />
                                                        Auto-dates
                                                    </button>
                                                    <button
                                                        onClick={() => deletePhase(project.id, phase.id)}
                                                        className="text-red-500 hover:text-red-700 p-1"
                                                        title="Delete phase"
                                                    >
                                                        <Icon name="trash" className="w-3 h-3" />
                                                    </button>
                                                    <button
                                                        onClick={() => addTask(project.id, phase.id)}
                                                        className="flex items-center gap-2 text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 text-sm"
                                                    >
                                                        <Icon name="plus" className="w-3 h-3" />
                                                        Add Task
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <div className="space-y-2">
                                                {phase.tasks.map((task, taskIndex) => {
                                                    const delayInfo = checkForDelays(task);
                                                    return (
                                                        <div key={task.id} className={`border border-gray-200 dark:border-gray-600 rounded p-3 ${delayInfo.isDelayed ? 'bg-red-50 dark:bg-red-900/20 border-red-300 dark:border-red-700' : ''}`}>
                                                            <div className="flex items-center justify-between">
                                                                <div className="flex items-center gap-3 flex-1">
                                                                    <div className="flex flex-col gap-1">
                                                                        <button
                                                                            onClick={() => moveTask(project.id, phase.id, task.id, 'up')}
                                                                            disabled={taskIndex === 0}
                                                                            className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed"
                                                                            title="Move task up"
                                                                        >
                                                                            <Icon name="chevronUp" className="w-3 h-3" />
                                                                        </button>
                                                                        <button
                                                                            onClick={() => moveTask(project.id, phase.id, task.id, 'down')}
                                                                            disabled={taskIndex === phase.tasks.length - 1}
                                                                            className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed"
                                                                            title="Move task down"
                                                                        >
                                                                            <Icon name="chevronDown" className="w-3 h-3" />
                                                                        </button>
                                                                    </div>
                                                                    
                                                                    <div className="flex-1">
                                                                        <input
                                                                            type="text"
                                                                            value={task.name}
                                                                            onChange={(e) => updateTask(project.id, phase.id, task.id, { name: e.target.value })}
                                                                            className="font-medium bg-transparent border-none outline-none text-gray-700 dark:text-gray-300 focus:bg-gray-50 dark:focus:bg-gray-700 px-2 py-1 rounded w-full"
                                                                        />
                                                                        <div className="flex items-center gap-4 mt-1 text-sm text-gray-500 dark:text-gray-400">
                                                                            <div className="flex items-center gap-2">
                                                                                <Icon name="calendar" className="w-3 h-3" />
                                                                                <input
                                                                                    type="date"
                                                                                    value={task.startDate}
                                                                                    onChange={(e) => updateTask(project.id, phase.id, task.id, { startDate: e.target.value })}
                                                                                    className="bg-transparent border border-gray-300 dark:border-gray-600 rounded px-2 py-1 text-xs focus:outline-none focus:border-blue-500 dark:bg-gray-700"
                                                                                />
                                                                                <span>to</span>
                                                                                <input
                                                                                    type="date"
                                                                                    value={task.endDate}
                                                                                    onChange={(e) => updateTask(project.id, phase.id, task.id, { endDate: e.target.value })}
                                                                                    className="bg-transparent border border-gray-300 dark:border-gray-600 rounded px-2 py-1 text-xs focus:outline-none focus:border-blue-500 dark:bg-gray-700"
                                                                                />
                                                                            </div>
                                                                            <select
                                                                                value={task.status}
                                                                                onChange={(e) => updateTask(project.id, phase.id, task.id, { status: e.target.value })}
                                                                                className="bg-transparent border border-gray-300 dark:border-gray-600 rounded px-2 py-1 text-xs focus:outline-none focus:border-blue-500 dark:bg-gray-700"
                                                                            >
                                                                                <option value="pending">Pending</option>
                                                                                <option value="in-progress">In Progress</option>
                                                                                <option value="completed">Completed</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                
                                                                <button
                                                                    onClick={() => deleteTask(project.id, phase.id, task.id)}
                                                                    className="text-red-500 hover:text-red-700 p-1"
                                                                >
                                                                    <Icon name="trash" className="w-4 h-4" />
                                                                </button>
                                                            </div>
                                                            
                                                            <TaskAssignmentEditor
                                                                task={task}
                                                                projectId={project.id}
                                                                phaseId={phase.id}
                                                                teams={teams}
                                                                findTeamMember={findTeamMember}
                                                                updateTask={updateTask}
                                                                checkForDelays={checkForDelays}
                                                            />
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ))}
                        </div>
                    )}
                    
                    {activeView === 'gantt' && (
                        <GanttChart 
                            projects={projects}
                            selectedProjects={selectedProjects}
                            setSelectedProjects={setSelectedProjects}
                            checkForDelays={checkForDelays}
                        />
                    )}
                    
                    {activeView === 'costs' && (
                        <CostView 
                            projects={projects}
                            teams={teams}
                            setTeams={setTeams}
                            findTeamMember={findTeamMember}
                            calculatePhaseCost={calculatePhaseCost}
                            calculateProjectTotals={calculateProjectTotals}
                            checkForDelays={checkForDelays}
                        />
                    )}
                    
                    {activeView === 'resources' && (
                        <ResourceView 
                            teams={teams}
                            calculateResourceAllocation={calculateResourceAllocation}
                        />
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;