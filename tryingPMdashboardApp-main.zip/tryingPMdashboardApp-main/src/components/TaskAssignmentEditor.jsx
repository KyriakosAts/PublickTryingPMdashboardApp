import { useState } from 'react';
import Icon from './Icon';
import { getDaysBetween } from '../utils/dateUtils';
import MemberSearchDropdown from './MemberSearchDropdown';
import { calculateTaskDuration, calculateTaskEndDate } from '../utils/dateCalculations';

const TaskAssignmentEditor = ({ task, projectId, phaseId, teams, findTeamMember, updateTask, checkForDelays }) => {
    const [showMemberSelector, setShowMemberSelector] = useState(false);
    const [selectedMember, setSelectedMember] = useState('');
    const [allocation, setAllocation] = useState('1.0');
    const [days, setDays] = useState('1');
    
    console.log('TaskAssignmentEditor render:', {
        taskId: task.id,
        taskName: task.name,
        currentAssignments: task.assignments,
        assignmentCount: task.assignments?.length || 0
    });
    
    const addAssignment = () => {
        console.log('Adding assignment:', { selectedMember, allocation, days });
        
        if (!selectedMember) {
            console.error('No member selected');
            return;
        }
        
        // Find the actual member object to get team info
        const memberObj = teams.flatMap(team => 
            team.members.map(member => ({
                ...member,
                teamName: team.name
            }))
        ).find(m => m.id === selectedMember);
        
        if (!memberObj) {
            console.error('Member not found:', selectedMember);
            console.log('Available members:', teams.flatMap(team => 
                team.members.map(member => ({ id: member.id, name: member.name, team: team.name }))
            ));
            return;
        }
        
        console.log('Found member object:', memberObj);
        
        const newAssignment = {
            teamMemberId: selectedMember,
            allocation: parseFloat(allocation),
            days: parseInt(days)
        };
        
        console.log('Creating new assignment:', newAssignment);
        
        const currentAssignments = task.assignments || [];
        const updatedAssignments = [...currentAssignments, newAssignment];
        
        console.log('Current assignments:', currentAssignments);
        console.log('Updated assignments:', updatedAssignments);
        
        // Update the task with new assignments
        updateTask(projectId, phaseId, task.id, { assignments: updatedAssignments });
        
        // Auto-recalculate end date based on new assignments
        const newEndDate = calculateTaskEndDate(task.startDate, task, updatedAssignments);
        updateTask(projectId, phaseId, task.id, { endDate: newEndDate });
        
        console.log('Task updated with assignments:', updatedAssignments);
        console.log('New end date calculated:', newEndDate);
        
        // Reset form
        setSelectedMember('');
        setAllocation('1.0');
        setDays('1');
        setShowMemberSelector(false);
    };
    
    const removeAssignment = (memberId) => {
        console.log('Removing assignment for member:', memberId);
        const updatedAssignments = (task.assignments || []).filter(a => a.teamMemberId !== memberId);
        console.log('Assignments after removal:', updatedAssignments);
        
        updateTask(projectId, phaseId, task.id, { assignments: updatedAssignments });
        
        // Auto-recalculate end date
        const newEndDate = calculateTaskEndDate(task.startDate, task, updatedAssignments);
        updateTask(projectId, phaseId, task.id, { endDate: newEndDate });
    };
    
    const updateAssignment = (memberId, field, value) => {
        console.log('Updating assignment:', { memberId, field, value });
        const updatedAssignments = (task.assignments || []).map(a => 
            a.teamMemberId === memberId 
                ? { ...a, [field]: field === 'allocation' ? parseFloat(value) : parseInt(value) }
                : a
        );
        console.log('Updated assignments:', updatedAssignments);
        
        updateTask(projectId, phaseId, task.id, { assignments: updatedAssignments });
        
        // Auto-recalculate end date
        const newEndDate = calculateTaskEndDate(task.startDate, task, updatedAssignments);
        updateTask(projectId, phaseId, task.id, { endDate: newEndDate });
    };
    
    const handleParallelizationChange = (newValue) => {
        console.log('Changing parallelization to:', newValue);
        updateTask(projectId, phaseId, task.id, { parallelizable: newValue });
        
        // Auto-recalculate end date with new parallelization factor
        const newEndDate = calculateTaskEndDate(task.startDate, task, task.assignments || []);
        updateTask(projectId, phaseId, task.id, { endDate: newEndDate });
    };
    
    const handleMemberSelect = (member) => {
        console.log('Member selected:', member);
        setSelectedMember(member ? member.id : '');
    };
    
    const delayInfo = checkForDelays(task);
    
    const estimatedDuration = calculateTaskDuration(task, task.assignments || []);
    const actualDuration = getDaysBetween(task.startDate, task.endDate);
    
    // Simple parallelization options
    const parallelizationOptions = [
        { value: 0.3, label: 'Sequential', color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' },
        { value: 0.5, label: 'Limited', color: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' },
        { value: 0.7, label: 'Moderate', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' },
        { value: 0.8, label: 'High', color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' },
        { value: 0.9, label: 'Very High', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' },
        { value: 1.0, label: 'Perfect', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200' }
    ];
    
    const currentParallelization = task.parallelizable || 0.8;
    
    console.log('Rendering assignments section. Current assignments:', task.assignments);
    
    return (
        <div className="mt-2 p-3 bg-gray-50 dark:bg-gray-700 rounded">
            {delayInfo.isDelayed && (
                <div className="mb-2 p-2 bg-red-100 dark:bg-red-900 border border-red-300 dark:border-red-700 rounded flex items-center gap-2">
                    <Icon name="alert" className="w-4 h-4 text-red-600 dark:text-red-400" />
                    <span className="text-xs text-red-700 dark:text-red-300">{delayInfo.message}</span>
                </div>
            )}
            
            <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-semibold text-gray-700 dark:text-gray-300">
                    Team Assignments ({(task.assignments || []).length})
                </h4>
                <button
                    onClick={() => setShowMemberSelector(!showMemberSelector)}
                    className="text-xs text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 flex items-center gap-1"
                >
                    <Icon name="plus" className="w-3 h-3" />
                    Add Member
                </button>
            </div>
            
            {showMemberSelector && (
                <div className="mb-3 p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-600">
                    <div className="mb-2">
                        <label className="text-xs text-gray-600 dark:text-gray-400 block mb-1">Team Member</label>
                        <MemberSearchDropdown
                            teams={teams}
                            selectedMember={selectedMember}
                            onMemberSelect={handleMemberSelect}
                            placeholder="Search and select team member..."
                        />
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2">
                        <div>
                            <label className="text-xs text-gray-600 dark:text-gray-400">Allocation</label>
                            <select
                                value={allocation}
                                onChange={(e) => setAllocation(e.target.value)}
                                className="w-full text-xs border border-gray-300 dark:border-gray-600 rounded px-2 py-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                            >
                                <option value="0.2">20%</option>
                                <option value="0.5">50%</option>
                                <option value="0.8">80%</option>
                                <option value="1.0">100%</option>
                            </select>
                        </div>
                        
                        <div>
                            <label className="text-xs text-gray-600 dark:text-gray-400">Days</label>
                            <input
                                type="number"
                                value={days}
                                onChange={(e) => setDays(e.target.value)}
                                min="0.5"
                                step="0.5"
                                className="w-full text-xs border border-gray-300 dark:border-gray-600 rounded px-2 py-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                            />
                        </div>
                        
                        <div className="flex items-end">
                            <button
                                onClick={addAssignment}
                                disabled={!selectedMember}
                                className="w-full text-xs bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-2 py-1 rounded"
                            >
                                Add
                            </button>
                        </div>
                    </div>
                    
                    <div className="mt-2 flex justify-end">
                        <button
                            onClick={() => setShowMemberSelector(false)}
                            className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            )}
            
            {/* Current Assignments */}
            <div className="space-y-1 mb-3">
                {console.log('About to render assignments. Task assignments:', task.assignments)}
                {(task.assignments || []).length === 0 ? (
                    <div className="text-xs text-gray-500 dark:text-gray-400 italic p-2 bg-gray-100 dark:bg-gray-600 rounded">
                        No team members assigned yet
                    </div>
                ) : (
                    (task.assignments || []).map(assignment => {
                        console.log('Rendering assignment:', assignment);
                        const member = findTeamMember(assignment.teamMemberId);
                        console.log('Found member for assignment:', member);
                        
                        if (!member) {
                            console.warn('Member not found for assignment:', assignment.teamMemberId);
                            return (
                                <div key={assignment.teamMemberId} className="flex items-center justify-between bg-red-100 dark:bg-red-900 p-2 rounded text-xs border border-red-300 dark:border-red-700">
                                    <span className="text-red-700 dark:text-red-300">
                                        Member not found: {assignment.teamMemberId}
                                    </span>
                                    <button
                                        onClick={() => removeAssignment(assignment.teamMemberId)}
                                        className="text-red-500 hover:text-red-700"
                                    >
                                        <Icon name="x" className="w-3 h-3" />
                                    </button>
                                </div>
                            );
                        }
                        
                        return (
                            <div key={assignment.teamMemberId} className="flex items-center justify-between bg-white dark:bg-gray-800 p-2 rounded text-xs border border-gray-200 dark:border-gray-600">
                                <div className="flex items-center gap-2">
                                    <span className="font-medium text-gray-900 dark:text-gray-100">{member.name}</span>
                                    <span className="text-gray-500 dark:text-gray-400">({member.teamName})</span>
                                    <span className="text-gray-600 dark:text-gray-300">${member.rate}/day</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <input
                                        type="number"
                                        value={assignment.allocation}
                                        onChange={(e) => updateAssignment(assignment.teamMemberId, 'allocation', e.target.value)}
                                        min="0.1"
                                        max="1"
                                        step="0.1"
                                        className="w-12 text-xs border border-gray-300 dark:border-gray-600 rounded px-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                    />
                                    <span className="text-gray-500 dark:text-gray-400">×</span>
                                    <input
                                        type="number"
                                        value={assignment.days}
                                        onChange={(e) => updateAssignment(assignment.teamMemberId, 'days', e.target.value)}
                                        min="0.5"
                                        step="0.5"
                                        className="w-12 text-xs border border-gray-300 dark:border-gray-600 rounded px-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                    />
                                    <span className="text-gray-500 dark:text-gray-400">days</span>
                                    <button
                                        onClick={() => removeAssignment(assignment.teamMemberId)}
                                        className="text-red-500 hover:text-red-700"
                                    >
                                        <Icon name="x" className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
            
            {/* Parallelization Factor - Simple Button Selection */}
            <div className="mb-3 p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-600">
                <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                        <Icon name="chart" className="w-3 h-3" />
                        Work Style
                    </label>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                        {Math.round(currentParallelization * 100)}% parallel
                    </span>
                </div>
                
                <div className="grid grid-cols-3 gap-1">
                    {parallelizationOptions.map((option) => (
                        <button
                            key={option.value}
                            onClick={() => handleParallelizationChange(option.value)}
                            className={`text-xs px-2 py-1 rounded transition-colors ${
                                Math.abs(option.value - currentParallelization) < 0.05
                                    ? option.color + ' font-medium'
                                    : 'bg-gray-100 dark:bg-gray-600 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-500'
                            }`}
                        >
                            {option.label}
                        </button>
                    ))}
                </div>
            </div>
            
            {/* Duration Information */}
            {(task.assignments || []).length > 0 && (
                <div className="pt-2 border-t border-gray-200 dark:border-gray-600">
                    <div className="grid grid-cols-2 gap-4 text-xs">
                        <div>
                            <span className="text-gray-600 dark:text-gray-400">Estimated Duration:</span>
                            <span className="ml-1 font-medium text-blue-600 dark:text-blue-400">
                                {estimatedDuration} days
                            </span>
                        </div>
                        <div>
                            <span className="text-gray-600 dark:text-gray-400">Current Duration:</span>
                            <span className={`ml-1 font-medium ${
                                actualDuration === estimatedDuration 
                                    ? 'text-green-600 dark:text-green-400' 
                                    : 'text-orange-600 dark:text-orange-400'
                            }`}>
                                {actualDuration} days
                            </span>
                        </div>
                    </div>
                    
                    {actualDuration !== estimatedDuration && (
                        <div className="mt-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded">
                            <div className="flex items-center gap-2">
                                <Icon name="alert" className="w-3 h-3 text-yellow-600 dark:text-yellow-400" />
                                <span className="text-xs text-yellow-700 dark:text-yellow-300">
                                    Duration mismatch: Dates auto-adjust when you modify assignments
                                </span>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default TaskAssignmentEditor;