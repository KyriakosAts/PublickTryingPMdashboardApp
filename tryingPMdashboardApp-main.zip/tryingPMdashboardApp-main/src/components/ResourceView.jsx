import React from 'react';

const ResourceView = ({ teams, calculateResourceAllocation }) => {
    const allocation = calculateResourceAllocation();
    
    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">Resource Allocation</h3>
            
            <div className="mb-8">
                <h4 className="text-md font-semibold text-gray-700 dark:text-gray-300 mb-3">Team Allocation Overview</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {teams.map(team => {
                        const teamAlloc = allocation.byTeam[team.name];
                        const teamCapacity = team.members.length * 20 * 3; // Assuming 3 months of projects
                        const utilization = Math.round((teamAlloc.total / teamCapacity) * 100);
                        
                        return (
                            <div key={team.name} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                                <div className="flex items-center justify-between mb-2">
                                    <div className="text-sm font-medium text-gray-600 dark:text-gray-400">{team.name}</div>
                                    <div className="text-lg font-bold text-gray-800 dark:text-gray-200">{teamAlloc.total} days</div>
                                </div>
                                <div className="text-xs text-gray-500 dark:text-gray-400">
                                    {team.members.length} members
                                </div>
                                <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2 mt-2">
                                    <div 
                                        className={`h-2 rounded-full ${utilization > 80 ? 'bg-red-500' : utilization > 60 ? 'bg-yellow-500' : 'bg-green-500'}`}
                                        style={{ width: `${Math.min(utilization, 100)}%` }}
                                    />
                                </div>
                                <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{utilization}% utilized</div>
                            </div>
                        );
                    })}
                </div>
            </div>
            
            <div className="mb-8">
                <h4 className="text-md font-semibold text-gray-700 dark:text-gray-300 mb-3">Individual Member Allocation</h4>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Team</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Member</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Level</th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Total Days</th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Active Tasks</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Utilization</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            {teams.map(team => 
                                team.members.map(member => {
                                    const memberAlloc = allocation.byMember[member.id];
                                    const workDaysPerMonth = 20;
                                    const totalMonths = 3;
                                    const capacity = workDaysPerMonth * totalMonths;
                                    const utilization = Math.round((memberAlloc.total / capacity) * 100);
                                    
                                    return (
                                        <tr key={member.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">{team.name}</td>
                                            <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">{member.name}</td>
                                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">{member.level}</td>
                                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100 text-center">{memberAlloc.total}</td>
                                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100 text-center">{memberAlloc.tasks.length}</td>
                                            <td className="px-4 py-2 whitespace-nowrap">
                                                <div className="flex items-center">
                                                    <div className="w-24 bg-gray-200 dark:bg-gray-600 rounded-full h-2 mr-2">
                                                        <div 
                                                            className={`h-2 rounded-full ${utilization > 80 ? 'bg-red-500' : utilization > 60 ? 'bg-yellow-500' : 'bg-green-500'}`}
                                                            style={{ width: `${Math.min(utilization, 100)}%` }}
                                                        />
                                                    </div>
                                                    <span className={`text-xs font-medium ${utilization > 80 ? 'text-red-600 dark:text-red-400' : utilization > 60 ? 'text-yellow-600 dark:text-yellow-400' : 'text-green-600 dark:text-green-400'}`}>
                                                        {utilization}%
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ResourceView;
