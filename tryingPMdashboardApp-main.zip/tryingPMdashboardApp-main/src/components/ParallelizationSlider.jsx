import React from 'react';
import Icon from './Icon';

const ParallelizationSlider = ({ value, onChange, taskId, className = "" }) => {
    const parallelizationLevels = [
        { value: 0.3, label: 'Sequential', description: 'Tasks must be done one after another', color: 'text-red-600 dark:text-red-400' },
        { value: 0.5, label: 'Limited', description: 'Some tasks can overlap', color: 'text-orange-600 dark:text-orange-400' },
        { value: 0.7, label: 'Moderate', description: 'Good parallelization possible', color: 'text-yellow-600 dark:text-yellow-400' },
        { value: 0.8, label: 'High', description: 'Most tasks can run in parallel', color: 'text-green-600 dark:text-green-400' },
        { value: 0.9, label: 'Very High', description: 'Excellent parallelization', color: 'text-blue-600 dark:text-blue-400' },
        { value: 1.0, label: 'Perfect', description: 'All tasks fully independent', color: 'text-purple-600 dark:text-purple-400' }
    ];
    
    const getCurrentLevel = () => {
        return parallelizationLevels.reduce((prev, curr) => 
            Math.abs(curr.value - value) < Math.abs(prev.value - value) ? curr : prev
        );
    };
    
    const currentLevel = getCurrentLevel();
    
    return (
        <div className={`bg-gray-50 dark:bg-gray-700 rounded-lg p-3 ${className}`}>
            <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                    <Icon name="chart" className="w-3 h-3" />
                    Parallelization Factor
                </label>
                <span className={`text-xs font-semibold ${currentLevel.color}`}>
                    {currentLevel.label} ({Math.round(value * 100)}%)
                </span>
            </div>
            
            <div className="mb-2">
                <input
                    type="range"
                    min="0.3"
                    max="1.0"
                    step="0.1"
                    value={value}
                    onChange={(e) => onChange(parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                    style={{
                        background: `linear-gradient(to right, 
                            #ef4444 0%, 
                            #f97316 20%, 
                            #eab308 40%, 
                            #22c55e 60%, 
                            #3b82f6 80%, 
                            #8b5cf6 100%)`
                    }}
                />
            </div>
            
            <div className="text-xs text-gray-500 dark:text-gray-400">
                {currentLevel.description}
            </div>
            
            <div className="mt-2 grid grid-cols-6 gap-1">
                {parallelizationLevels.map((level, index) => (
                    <button
                        key={level.value}
                        onClick={() => onChange(level.value)}
                        className={`text-xs px-1 py-1 rounded transition-colors ${
                            Math.abs(level.value - value) < 0.05
                                ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 font-medium'
                                : 'hover:bg-gray-100 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-400'
                        }`}
                        title={level.description}
                    >
                        {Math.round(level.value * 100)}%
                    </button>
                ))}
            </div>
        </div>
    );
};

export default ParallelizationSlider;