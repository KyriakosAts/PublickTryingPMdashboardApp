import React, { useState, useEffect, useRef } from 'react';
import Icon from './Icon';

const MemberSearchDropdown = ({ teams, selectedMember, onMemberSelect, placeholder = "Search team members..." }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const [filteredMembers, setFilteredMembers] = useState([]);
    const dropdownRef = useRef(null);
    const inputRef = useRef(null);
    
    // Flatten all team members with team info
    const allMembers = teams.flatMap(team => 
        team.members.map(member => ({
            ...member,
            teamName: team.name
        }))
    );
    
    useEffect(() => {
        if (searchTerm) {
            const filtered = allMembers.filter(member =>
                member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                member.teamName.toLowerCase().includes(searchTerm.toLowerCase())
            );
            setFilteredMembers(filtered);
        } else {
            setFilteredMembers(allMembers);
        }
    }, [searchTerm, teams]);
    
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
    
    const handleMemberSelect = (member) => {
        onMemberSelect(member);
        setSearchTerm(member.name);
        setIsOpen(false);
    };
    
    const handleInputChange = (e) => {
        setSearchTerm(e.target.value);
        setIsOpen(true);
    };
    
    const handleInputFocus = () => {
        setIsOpen(true);
    };
    
    const clearSelection = () => {
        setSearchTerm('');
        onMemberSelect(null);
        setIsOpen(false);
        inputRef.current?.focus();
    };
    
    // Set display value based on selected member
    const displayValue = selectedMember ? 
        allMembers.find(m => m.id === selectedMember)?.name || '' : 
        searchTerm;
    
    return (
        <div ref={dropdownRef} className="relative">
            <div className="relative">
                <input
                    ref={inputRef}
                    type="text"
                    value={displayValue}
                    onChange={handleInputChange}
                    onFocus={handleInputFocus}
                    placeholder={placeholder}
                    className="w-full text-xs border border-gray-300 dark:border-gray-600 rounded px-2 py-1 pr-8 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                />
                {selectedMember && (
                    <button
                        onClick={clearSelection}
                        className="absolute right-6 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                        <Icon name="x" className="w-3 h-3" />
                    </button>
                )}
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2 pointer-events-none">
                    <Icon name="chevronDown" className="w-3 h-3 text-gray-400" />
                </div>
            </div>
            
            {isOpen && (
                <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg max-h-48 overflow-y-auto">
                    {filteredMembers.length > 0 ? (
                        filteredMembers.map(member => (
                            <div
                                key={member.id}
                                onClick={() => handleMemberSelect(member)}
                                className="px-3 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                            >
                                <div className="flex items-center justify-between">
                                    <div>
                                        <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                            {member.name}
                                        </div>
                                        <div className="text-xs text-gray-500 dark:text-gray-400">
                                            {member.teamName} • {member.level} • ${member.rate}/day
                                        </div>
                                    </div>
                                    {selectedMember === member.id && (
                                        <Icon name="check" className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                                    )}
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="px-3 py-2 text-sm text-gray-500 dark:text-gray-400">
                            No members found
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default MemberSearchDropdown;