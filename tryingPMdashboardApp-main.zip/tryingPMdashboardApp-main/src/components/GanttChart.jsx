import React from 'react';
import { getDaysBetween, formatDate } from '../utils/dateUtils';
import Icon from './Icon';

const GanttChart = ({ projects, selectedProjects, setSelectedProjects, checkForDelays }) => {
    // Calculate tasks and dates for selected projects
    const selectedProjectsData = projects.filter(p => selectedProjects.includes(p.id));
    const allTasks = [];
    let minDate = null;
    let maxDate = null;
    
    selectedProjectsData.forEach(project => {
        project.phases.forEach(phase => {
            phase.tasks.forEach(task => {
                allTasks.push({
                    ...task,
                    projectId: project.id,
                    projectName: project.name,
                    phaseId: phase.id,
                    phaseName: phase.name,
                    phaseColor: phase.color
                });
                
                if (!minDate || new Date(task.startDate) < new Date(minDate)) {
                    minDate = task.startDate;
                }
                if (!maxDate || new Date(task.endDate) > new Date(maxDate)) {
                    maxDate = task.endDate;
                }
            });
        });
    });
    
    // Calculate chart dimensions and timeline
    let totalDays = 0;
    let months = [];
    let dayWidth = 30;
    let rowHeight = 35;
    
    if (minDate && maxDate) {
        totalDays = getDaysBetween(minDate, maxDate);
        
        const currentDate = new Date(minDate);
        const endDate = new Date(maxDate);
        
        while (currentDate <= endDate) {
            const month = currentDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
            const remainingDays = Math.min(daysInMonth - currentDate.getDate() + 1, 
                Math.ceil((endDate - currentDate) / (1000 * 60 * 60 * 24)) + 1);
            
            months.push({ month, days: remainingDays });
            currentDate.setMonth(currentDate.getMonth() + 1);
            currentDate.setDate(1);
        }
    }
    
    const getTaskPosition = (task) => {
        const start = getDaysBetween(minDate, task.startDate);
        const duration = getDaysBetween(task.startDate, task.endDate);
        return {
            left: start * dayWidth,
            width: duration * dayWidth
        };
    };
    
    return (
        <div className="gantt-container bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Gantt Chart View</h3>
                
                <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Show Projects:</span>
                    <div className="flex gap-2">
                        {projects.map(project => (
                            <label key={project.id} className="flex items-center gap-1 cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={selectedProjects.includes(project.id)}
                                    onChange={(e) => {
                                        if (e.target.checked) {
                                            setSelectedProjects([...selectedProjects, project.id]);
                                        } else {
                                            setSelectedProjects(selectedProjects.filter(id => id !== project.id));
                                        }
                                    }}
                                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                />
                                <span className="text-sm text-gray-700 dark:text-gray-300">{project.name}</span>
                            </label>
                        ))}
                    </div>
                </div>
            </div>
            
            {selectedProjects.length === 0 ? (
                <div className="text-center py-12">
                    <div className="text-gray-400 dark:text-gray-500 mb-4">
                        <Icon name="chart" className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400 mb-2">No Projects Selected</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-500">
                            Select one or more projects above to view their Gantt chart
                        </p>
                    </div>
                </div>
            ) : !minDate || !maxDate ? (
                <div className="text-center py-12">
                    <div className="text-gray-400 dark:text-gray-500 mb-4">
                        <Icon name="alert" className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400 mb-2">No Tasks to Display</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-500">
                            The selected projects don't have any tasks with dates
                        </p>
                    </div>
                </div>
            ) : (
                <div className="relative">
                    <div className="flex border-b-2 border-gray-300 dark:border-gray-600 mb-2">
                        {months.map((m, idx) => (
                            <div 
                                key={idx} 
                                className="border-r border-gray-200 dark:border-gray-700 px-2 py-1 text-sm font-medium text-gray-700 dark:text-gray-300"
                                style={{ width: m.days * dayWidth }}
                            >
                                {m.month}
                            </div>
                        ))}
                    </div>
                    
                    <div className="flex border-b border-gray-200 dark:border-gray-700 mb-4">
                        {[...Array(totalDays)].map((_, i) => {
                            const date = new Date(minDate);
                            date.setDate(date.getDate() + i);
                            const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                            return (
                                <div 
                                    key={i} 
                                    className={`border-r border-gray-100 dark:border-gray-800 text-xs text-center ${
                                        isWeekend 
                                            ? 'bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500' 
                                            : 'text-gray-500 dark:text-gray-400'
                                    }`}
                                    style={{ width: dayWidth }}
                                >
                                    {date.getDate()}
                                    {date.getDate() === 1 && (
                                        <div className="text-xs font-medium text-gray-600 dark:text-gray-300">
                                            {date.toLocaleDateString('en-US', { month: 'short' })}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                    
                    <div className="relative" style={{ minWidth: totalDays * dayWidth }}>
                        <div className="absolute inset-0 pointer-events-none">
                            {[...Array(totalDays)].map((_, i) => (
                                (() => {
                                    const date = new Date(minDate);
                                    date.setDate(date.getDate() + i);
                                    const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                                    return (
                                        <div 
                                            key={i} 
                                            className={`absolute top-0 bottom-0 border-l ${
                                                isWeekend 
                                                    ? 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700' 
                                                    : 'border-gray-100 dark:border-gray-800'
                                            }`}
                                            style={{ left: i * dayWidth, width: dayWidth }}
                                        />
                                    );
                                })()
                            ))}
                        </div>
                        
                        {selectedProjectsData.map((project, projectIdx) => (
                            <div key={project.id} className="mb-6">
                                <div className="font-semibold text-gray-800 dark:text-gray-200 mb-2">{project.name}</div>
                                {project.phases.map((phase, phaseIdx) => (
                                    <div key={phase.id} className="mb-4">
                                        <div className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">{phase.name}</div>
                                        {phase.tasks.map((task, taskIdx) => {
                                            const position = getTaskPosition(task);
                                            const taskRow = allTasks.findIndex(t => t.id === task.id);
                                            const delayInfo = checkForDelays(task);
                                            
                                            return (
                                                <div key={task.id} className="relative" style={{ height: rowHeight }}>
                                                    <div 
                                                        className={`gantt-bar text-white text-xs ${delayInfo.isDelayed ? 'ring-2 ring-red-500' : ''}`}
                                                        style={{
                                                            left: position.left,
                                                            width: position.width,
                                                            backgroundColor: phase.color,
                                                            opacity: 0.9,
                                                            minWidth: '60px'
                                                        }}
                                                        title={`${task.name}: ${formatDate(task.startDate)} - ${formatDate(task.endDate)}${delayInfo.isDelayed ? ' (DELAYED)' : ''}`}
                                                    >
                                                        <span className="truncate">{task.name}</span>
                                                        {delayInfo.isDelayed && (
                                                            <Icon name="alert" className="w-3 h-3 ml-1 inline" />
                                                        )}
                                                        <div className="text-xs opacity-75 mt-1">
                                                            {getDaysBetween(task.startDate, task.endDate)}d
                                                        </div>
                                                    </div>
                                                    
                                                    {task.dependencies && task.dependencies.map(depId => {
                                                        const depTask = allTasks.find(t => t.id === depId);
                                                        if (!depTask) return null;
                                                        
                                                        const depPosition = getTaskPosition(depTask);
                                                        const depRow = allTasks.findIndex(t => t.id === depId);
                                                        
                                                        return (
                                                            <svg
                                                                key={depId}
                                                                className="absolute pointer-events-none"
                                                                style={{
                                                                    left: 0,
                                                                    top: -((taskRow - depRow) * rowHeight),
                                                                    width: totalDays * dayWidth,
                                                                    height: Math.abs(taskRow - depRow) * rowHeight + rowHeight
                                                                }}
                                                            >
                                                                <path
                                                                    d={`M${depPosition.left + depPosition.width},${rowHeight/2} 
                                                                       L${position.left - 5},${rowHeight/2} 
                                                                       L${position.left - 5},${(taskRow - depRow) * rowHeight + rowHeight/2}
                                                                       L${position.left},${(taskRow - depRow) * rowHeight + rowHeight/2}`}
                                                                    stroke="#999"
                                                                    strokeWidth="2"
                                                                    fill="none"
                                                                    strokeDasharray="5,5"
                                                                />
                                                                <polygon
                                                                    points={`${position.left},${(taskRow - depRow) * rowHeight + rowHeight/2} 
                                                                            ${position.left - 8},${(taskRow - depRow) * rowHeight + rowHeight/2 - 4} 
                                                                            ${position.left - 8},${(taskRow - depRow) * rowHeight + rowHeight/2 + 4}`}
                                                                    fill="#999"
                                                                />
                                                            </svg>
                                                        );
                                                    })}
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default GanttChart;
