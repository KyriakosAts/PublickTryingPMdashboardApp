import React, { useState } from 'react';
import Icon from './Icon';

const CostView = ({ 
    projects, 
    teams, 
    setTeams, 
    findTeamMember, 
    calculatePhaseCost, 
    calculateProjectTotals,
    checkForDelays 
}) => {
    const [addingMemberToTeam, setAddingMemberToTeam] = useState(null);
    const [newMemberName, setNewMemberName] = useState('');
    const [newMemberRate, setNewMemberRate] = useState('');
    const [newMemberLevel, setNewMemberLevel] = useState('Mid');
    
    const addTeamMember = (teamName) => {
        if (newMemberName && newMemberRate) {
            const memberId = `${teamName.toLowerCase()}${Date.now()}`;
            const newMember = {
                id: memberId,
                name: newMemberName,
                rate: parseInt(newMemberRate) || 500,
                level: newMemberLevel
            };
            
            setTeams(teams.map(t => 
                t.name === teamName 
                    ? { ...t, members: [...t.members, newMember] }
                    : t
            ));
            
            setNewMemberName('');
            setNewMemberRate('');
            setNewMemberLevel('Mid');
            setAddingMemberToTeam(null);
        }
    };
    
    const deleteTeamMember = (teamName, memberId) => {
        setTeams(teams.map(t => 
            t.name === teamName 
                ? { ...t, members: t.members.filter(m => m.id !== memberId) }
                : t
        ));
    };
    
    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">Cost Analysis</h3>
            
            <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Team Members & Daily Rates</h4>
                {teams.map(team => (
                    <div key={team.name} className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                            <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300">{team.name} Team</h5>
                            <button
                                onClick={() => setAddingMemberToTeam(addingMemberToTeam === team.name ? null : team.name)}
                                className="text-xs text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 flex items-center gap-1"
                            >
                                <Icon name="plus" className="w-3 h-3" />
                                Add Member
                            </button>
                        </div>
                        
                        {addingMemberToTeam === team.name && (
                            <div className="mb-3 p-3 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-600">
                                <div className="grid grid-cols-4 gap-2">
                                    <input
                                        type="text"
                                        value={newMemberName}
                                        onChange={(e) => setNewMemberName(e.target.value)}
                                        placeholder="Member name"
                                        className="text-sm border border-gray-300 dark:border-gray-600 rounded px-2 py-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                    />
                                    <input
                                        type="number"
                                        value={newMemberRate}
                                        onChange={(e) => setNewMemberRate(e.target.value)}
                                        placeholder="Daily rate"
                                        className="text-sm border border-gray-300 dark:border-gray-600 rounded px-2 py-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                    />
                                    <select
                                        value={newMemberLevel}
                                        onChange={(e) => setNewMemberLevel(e.target.value)}
                                        className="text-sm border border-gray-300 dark:border-gray-600 rounded px-2 py-1 focus:outline-none focus:border-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                    >
                                        <option value="Senior">Senior</option>
                                        <option value="Mid">Mid</option>
                                        <option value="Junior">Junior</option>
                                    </select>
                                    <button
                                        onClick={() => addTeamMember(team.name)}
                                        className="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1 rounded"
                                    >
                                        Add
                                    </button>
                                </div>
                            </div>
                        )}
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                            {team.members.map(member => (
                                <div key={member.id} className="bg-white dark:bg-gray-800 p-2 rounded border border-gray-200 dark:border-gray-600">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <div className="text-sm font-medium text-gray-700 dark:text-gray-300">{member.name}</div>
                                            <div className="text-xs text-gray-500 dark:text-gray-400">{member.level}</div>
                                            <div className="text-sm font-semibold text-gray-800 dark:text-gray-200">${member.rate}/day</div>
                                        </div>
                                        <button
                                            onClick={() => deleteTeamMember(team.name, member.id)}
                                            className="text-red-500 hover:text-red-700"
                                        >
                                            <Icon name="trash" className="w-3 h-3" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                        
                        {addingMemberToTeam === team.name && (
                            <div className="mt-2 flex justify-end">
                                <button
                                    onClick={() => setAddingMemberToTeam(null)}
                                    className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                                >
                                    Cancel
                                </button>
                            </div>
                        )}
                    </div>
                ))}
            </div>
            
            {projects.map(project => {
                const projectTotals = calculateProjectTotals(project);
                return (
                    <div key={project.id} className="mb-8">
                        <div className="flex items-center justify-between mb-4">
                            <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200">{project.name}</h4>
                            <div className="text-xl font-bold text-green-600 dark:text-green-400">
                                ${projectTotals.cost.toLocaleString()}
                            </div>
                        </div>
                        
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead className="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Phase</th>
                                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Task</th>
                                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Assigned Members</th>
                                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Days</th>
                                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Task Cost</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    {project.phases.map(phase => {
                                        const phaseCost = calculatePhaseCost(phase);
                                        return (
                                            <React.Fragment key={phase.id}>
                                                {phase.tasks.map((task, taskIdx) => {
                                                    let taskCost = 0;
                                                    const memberDetails = [];
                                                    
                                                    task.assignments?.forEach(assignment => {
                                                        const member = findTeamMember(assignment.teamMemberId);
                                                        if (member) {
                                                            const cost = assignment.days * member.rate;
                                                            taskCost += cost;
                                                            memberDetails.push({
                                                                name: member.name,
                                                                team: member.teamName,
                                                                days: assignment.days,
                                                                allocation: assignment.allocation,
                                                                cost: cost
                                                            });
                                                        } else {
                                                            console.warn('Member not found for assignment:', assignment.teamMemberId);
                                                        }
                                                    });
                                                    
                                                    const delayInfo = checkForDelays(task);
                                                    
                                                    return (
                                                        <tr key={task.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700 ${delayInfo.isDelayed ? 'bg-red-50 dark:bg-red-900/20' : ''}`}>
                                                            {taskIdx === 0 && (
                                                                <td rowSpan={phase.tasks.length} className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100 border-r dark:border-gray-700">
                                                                    {phase.name}
                                                                </td>
                                                            )}
                                                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                                                {task.name}
                                                                {delayInfo.isDelayed && (
                                                                    <span className="ml-2 text-red-600 dark:text-red-400">
                                                                        <Icon name="alert" className="w-3 h-3 inline" />
                                                                    </span>
                                                                )}
                                                            </td>
                                                            <td className="px-4 py-2 text-xs text-gray-600 dark:text-gray-400">
                                                                {memberDetails.map((detail, idx) => (
                                                                    <div key={idx}>
                                                                        {detail.name} ({detail.team}) - {detail.days}d @ {(detail.allocation * 100)}%
                                                                    </div>
                                                                ))}
                                                            </td>
                                                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100 text-right">
                                                                {task.assignments?.reduce((sum, a) => sum + a.days, 0) || 0}
                                                            </td>
                                                            <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100 text-right">
                                                                ${taskCost.toLocaleString()}
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                                <tr className="bg-gray-50 dark:bg-gray-700 font-semibold">
                                                    <td colSpan={4} className="px-4 py-2 text-sm text-gray-900 dark:text-gray-100">Phase Total</td>
                                                    <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-100 text-right">
                                                        ${phaseCost.toLocaleString()}
                                                    </td>
                                                </tr>
                                            </React.Fragment>
                                        );
                                    })}
                                    <tr className="bg-gray-100 dark:bg-gray-600 font-bold">
                                        <td colSpan={4} className="px-4 py-2 text-sm text-gray-900 dark:text-gray-100">Project Total</td>
                                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-100 text-right">
                                            ${projectTotals.cost.toLocaleString()}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            })}
            
            <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Portfolio Summary</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Total Projects</div>
                        <div className="text-2xl font-bold text-gray-800 dark:text-gray-200">{projects.length}</div>
                    </div>
                    <div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Total Cost</div>
                        <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                            ${projects.reduce((sum, p) => sum + calculateProjectTotals(p).cost, 0).toLocaleString()}
                        </div>
                    </div>
                    <div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Total Team Members</div>
                        <div className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                            {teams.reduce((sum, t) => sum + t.members.length, 0)}
                        </div>
                    </div>
                    <div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Avg Member Rate</div>
                        <div className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                            ${Math.round(
                                teams.reduce((sum, t) => sum + t.members.reduce((mSum, m) => mSum + m.rate, 0), 0) / 
                                teams.reduce((sum, t) => sum + t.members.length, 0)
                            ).toLocaleString()}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CostView;