import { addDays, getDaysBetween } from './dateUtils';

// Calculate task duration based on effort and team assignments
export const calculateTaskDuration = (task, assignments = []) => {
    if (!task.effort || assignments.length === 0) {
        return 5; // Default 5 days if no effort or assignments
    }
    
    // Calculate total effort needed (sum of all effort values)
    const totalEffort = Object.values(task.effort).reduce((sum, val) => sum + val, 0);
    
    if (totalEffort === 0) return 1;
    
    // Calculate total daily capacity from assignments
    const totalDailyCapacity = assignments.reduce((sum, assignment) => {
        return sum + (assignment.allocation || 1);
    }, 0);
    
    if (totalDailyCapacity === 0) return totalEffort;
    
    // Calculate ideal duration
    const idealDuration = totalEffort / totalDailyCapacity;
    
    // Apply parallelization factor (lower factor = less parallel work possible)
    const parallelFactor = task.parallelizable || 0.8;
    const actualDuration = idealDuration / parallelFactor;
    
    return Math.ceil(Math.max(1, actualDuration));
};

// Calculate task end date based on start date and assignments
export const calculateTaskEndDate = (startDate, task, assignments = []) => {
    const duration = calculateTaskDuration(task, assignments);
    return addDays(startDate, duration - 1); // -1 because start date counts as day 1
};

// Auto-calculate task dates based on dependencies and assignments
export const autoCalculateTaskDates = (tasks, projectStartDate = null) => {
    const updatedTasks = [...tasks];
    const taskMap = new Map();
    
    // Create a map for quick task lookup
    updatedTasks.forEach(task => {
        taskMap.set(task.id, task);
    });
    
    // Sort tasks by dependencies (tasks with no dependencies first)
    const sortedTasks = [...updatedTasks].sort((a, b) => {
        const aDeps = a.dependencies?.length || 0;
        const bDeps = b.dependencies?.length || 0;
        return aDeps - bDeps;
    });
    
    sortedTasks.forEach(task => {
        let startDate;
        
        if (!task.dependencies || task.dependencies.length === 0) {
            // No dependencies - use project start date or current start date
            startDate = projectStartDate || task.startDate;
        } else {
            // Has dependencies - start after the latest dependency ends
            let latestEndDate = projectStartDate || task.startDate;
            
            task.dependencies.forEach(depId => {
                const depTask = taskMap.get(depId);
                if (depTask && depTask.endDate) {
                    const depEndDate = new Date(depTask.endDate);
                    const nextDay = addDays(depTask.endDate, 1);
                    if (new Date(nextDay) > new Date(latestEndDate)) {
                        latestEndDate = nextDay;
                    }
                }
            });
            
            startDate = latestEndDate;
        }
        
        // Calculate end date based on assignments
        const endDate = calculateTaskEndDate(startDate, task, task.assignments);
        
        // Update the task in the map and array
        task.startDate = startDate;
        task.endDate = endDate;
        taskMap.set(task.id, task);
    });
    
    return updatedTasks;
};

// Get business days between dates (excluding weekends)
export const getBusinessDaysBetween = (startDate, endDate) => {
    let count = 0;
    const current = new Date(startDate);
    const end = new Date(endDate);
    
    while (current <= end) {
        const dayOfWeek = current.getDay();
        if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday (0) or Saturday (6)
            count++;
        }
        current.setDate(current.getDate() + 1);
    }
    
    return count;
};