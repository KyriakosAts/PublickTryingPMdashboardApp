// Generate distinct colors for phases
export const generatePhaseColors = () => {
    return [
        '#3B82F6', // Blue
        '#10B981', // Emerald
        '#8B5CF6', // Violet
        '#F59E0B', // Amber
        '#EF4444', // Red
        '#EC4899', // Pink
        '#06B6D4', // Cyan
        '#84CC16', // Lime
        '#F97316', // Orange
        '#6366F1', // Indigo
        '#14B8A6', // Teal
        '#A855F7', // Purple
        '#22C55E', // Green
        '#F43F5E', // Rose
        '#0EA5E9', // Sky
        '#65A30D', // Green-600
        '#DC2626', // Red-600
        '#7C3AED', // Violet-600
        '#059669', // Emerald-600
        '#D97706'  // Amber-600
    ];
};

export const getPhaseColor = (phaseIndex) => {
    const colors = generatePhaseColors();
    return colors[phaseIndex % colors.length];
};